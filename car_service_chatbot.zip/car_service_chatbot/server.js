// server.js
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

app.post('/chat', (req, res) => {
  const userQuery = req.body.query.toLowerCase();
  
  // Process the user query and generate a response
  let response = 'Sorry, I could not understand that.';

  // Define responses for different queries
  const responses = {
    'brakes squeaking': 'Squeaking brakes could be a sign of worn-out brake pads or a buildup of brake dust. It\'s best to have them checked by a mechanic.',
    'change oil': 'You should change your oil every 3,000 to 5,000 miles, or as recommended in your vehicle\'s owner manual.',
    'car won’t start': 'If your car won’t start, it could be due to a dead battery, faulty starter, or an issue with the ignition system.',
    'car overheating': 'If your car is overheating, pull over safely and turn off the engine. Check the coolant level and look for leaks. It’s best to have it inspected by a professional.',
    'engine rattling': 'A rattling noise could indicate a loose or damaged engine component. Have a mechanic check it out as soon as possible.',
    'tires need replacing': 'Check the tread depth of your tires. If the tread is less than 2/32 of an inch, or if you see visible damage or bulges, it’s time to replace them.',
    'air conditioner not working': 'If your air conditioner isn’t working, it could be due to a refrigerant leak or a malfunctioning compressor. Have it checked by a technician.',
    'transmission fluid flush': 'A transmission fluid flush involves removing old transmission fluid and replacing it with new fluid to ensure smooth transmission operation.',
    'check engine light': 'The check engine light can indicate a range of issues from a loose gas cap to more serious engine problems. It’s best to have your vehicle’s diagnostics checked.',
    'replace air filter': 'Air filters should typically be replaced every 12,000 to 15,000 miles, but check your vehicle’s manual for specific recommendations.',
    'car pulling to one side': 'If your car pulls to one side, it could be due to an alignment issue or uneven tire pressure. Have the alignment checked and tires inspected.',
    'brake fluid': 'Brake fluid is a hydraulic fluid used in your vehicle’s braking system to transfer force from the brake pedal to the brake pads.',
    'fuel economy': 'Improve fuel economy by keeping your car well-maintained, maintaining proper tire pressure, and driving smoothly.',
    'grinding noise braking': 'Grinding noises when braking often indicate worn brake pads or damaged rotors. Have them inspected and replaced if necessary.',
    'battery load test': 'A battery load test measures the battery’s ability to hold a charge under load conditions, helping to determine its health.',
    'battery dead': 'If your car has trouble starting, the lights are dim, or there are clicking sounds when you turn the key, your battery might be dead.',
    'engine stalling': 'Engine stalling can be caused by a variety of issues, including fuel system problems or ignition issues. Have it diagnosed by a mechanic.',
    'check fluids': 'Check your car’s fluids (oil, coolant, brake fluid) at least once a month or before long trips.',
    'bad alternator': 'Signs of a bad alternator include dimming headlights, a dead battery, and warning lights on your dashboard.',
    'steering wheel vibrating': 'A vibrating steering wheel can be caused by unbalanced tires, misalignment, or worn steering components. Have it checked by a professional.',
    'serpentine belt': 'The serpentine belt is a single, continuous belt that drives multiple peripheral devices in your engine, such as the alternator and air conditioner.',
    'spark plugs': 'Signs of worn spark plugs include difficulty starting the engine, poor fuel economy, and rough idling.',
    'catalytic converter': 'A catalytic converter is a component of the exhaust system that reduces harmful emissions by converting them into less harmful substances.',
    'exhaust smell rotten eggs': 'A rotten egg smell from the exhaust often indicates a problem with the catalytic converter or an issue with the fuel system.',
    'prevent rusting': 'Prevent rust by regularly washing your car, applying wax, and addressing any paint chips or scratches promptly.',
    'coolant flush': 'A coolant flush involves removing old coolant from your engine and replacing it with fresh coolant to maintain proper engine temperature.',
    'shocks worn out': 'Signs of worn shocks include excessive bouncing, poor handling, and a rough ride.',
    'transmission slipping': 'Transmission slipping can indicate low transmission fluid or internal issues. Have it inspected by a professional.',
    'rotate tires': 'Rotate your tires every 6,000 to 8,000 miles to ensure even wear and extend their lifespan.',
    'differential': 'A differential is a gear system that allows your wheels to rotate at different speeds, especially important when turning corners.',
    'engine overheating': 'Engine overheating can be caused by low coolant levels, a faulty thermostat, or a failing water pump.',
    'timing belt': 'The timing belt is a crucial engine component that ensures the camshaft and crankshaft rotate in sync for proper engine operation.',
    'fuel pump failing': 'Signs of a failing fuel pump include difficulty starting, poor acceleration, and engine sputtering.',
    'airbag light on': 'An illuminated airbag light indicates a problem with the airbag system. Have it inspected immediately to ensure your safety.',
    'alignment checked': 'Have your car’s alignment checked every 12,000 to 15,000 miles or if you notice uneven tire wear.',
    'PCV valve': 'The PCV (Positive Crankcase Ventilation) valve helps reduce harmful emissions by allowing gases to escape from the engine\'s crankcase.',
    'brake pedal spongy': 'A spongy brake pedal can indicate air in the brake lines or a problem with the brake system. Have it inspected and serviced.',
    'fuel injectors cleaning': 'Symptoms of dirty fuel injectors include poor acceleration, rough idling, and decreased fuel efficiency.',
    'O2 sensor': 'The O2 (oxygen) sensor measures the amount of oxygen in the exhaust gases and helps optimize fuel efficiency and emissions.',
    'braking performance': 'Improve braking performance by maintaining your brake system, including replacing brake pads and fluid as needed.',
    'oil pressure light': 'The oil pressure light indicates low oil pressure, which could be due to low oil levels or a failing oil pump. Check your oil level and have it inspected.',
    'drive belt': 'A drive belt, also known as a serpentine belt, powers various engine components such as the alternator, water pump, and air conditioner.',
    'tire pressure': 'Use a tire pressure gauge to check your car’s tire pressure. Refer to the vehicle’s manual for the recommended pressure levels.',
    'brake rotor': 'The brake rotor is a disc that the brake pads press against to slow or stop the vehicle. It plays a crucial role in the braking system.',
    'transmission fluid change': 'Regularly changing your transmission fluid helps maintain smooth shifting and extends the life of your transmission.',
    'engine knocking': 'Engine knocking can be caused by poor fuel quality or issues with the ignition timing. Have it checked by a mechanic if it persists.',
    'air conditioning maintenance': 'Regularly check and maintain your air conditioning system to ensure it operates efficiently and effectively.',
    'windshield wipers': 'Replace your windshield wipers every 6 to 12 months or as soon as you notice streaking or reduced visibility.',
    'car battery life': 'Car batteries typically last 3 to 5 years. Regularly check battery health and replace it if you notice signs of weakness.',
    'exhaust system check': 'Have your exhaust system checked periodically for leaks, rust, or damage to ensure it functions properly and reduces emissions.',
    'coolant level check': 'Regularly check your coolant level and top it off as needed to prevent overheating and engine damage.',
    'engine oil level': 'Check your engine oil level regularly and top it off as needed to ensure proper engine lubrication and performance.',
    'fuel filter replacement': 'Replace your fuel filter every 20,000 to 30,000 miles to maintain proper fuel flow and engine performance.',
    'car alignment issues': 'Signs of alignment issues include uneven tire wear, pulling to one side, and a steering wheel that’s off-center.',
    'timing chain': 'A timing chain performs the same function as a timing belt but is typically more durable and requires less frequent replacement.'
  };

  // Check if the user query matches any of the predefined queries
  for (const [key, value] of Object.entries(responses)) {
    if (userQuery.includes(key)) {
      response = value;
      break;
    }
  }

  res.json({ response: response });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
